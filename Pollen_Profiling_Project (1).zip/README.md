# Pollen's Profiling: Automated Classification of Pollen Grains

## Team ID: LTVIP2025TMID43933

## Team Members:
- S. Jayarajeswari
- K. Lokeswari
- K. Harsha Vardhan
- K. Nithin

## Description
This project focuses on building an AI-based system to classify different types of pollen grains using deep learning and image processing techniques.

## Structure
- `Report/`: Contains the final project report.
- `Dataset/`: Sample pollen images.
- `Code/`: Image preprocessing and model training code.
- `App/`: Streamlit application to test the model.
- `Requirements.txt`: Python dependencies.

## How to Run
1. Install dependencies using `pip install -r Requirements.txt`
2. Run the Streamlit app using `streamlit run App/streamlit_app.py`
